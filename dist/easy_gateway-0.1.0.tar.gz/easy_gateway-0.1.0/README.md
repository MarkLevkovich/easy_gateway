# 🚀 Easy Gateway

Простой и легкий API шлюз на FastAPI для микросервисной архитектуры.

## ✨ Особенности

- ✅ Простая настройка через YAML
- ✅ CLI интерфейс
- ✅ Система middleware
- ✅ Маршрутизация с префиксами
- ✅ Rate limiting
- ✅ Логирование

## 📦 Установка

```bash
pip install easy-gateway
